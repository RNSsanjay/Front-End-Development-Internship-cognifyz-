// script.js

document.addEventListener('DOMContentLoaded', function() {
  const changeTextColorButton = document.getElementById('changeTextColor');
  const changeBgColorButton = document.getElementById('changeBgColor');
  const changeTextSizeButton = document.getElementById('changeTextSize');
  const changeTextStyleButton = document.getElementById('changeTextStyle');
  const resetButton = document.getElementById('resetButton');
  const bounceButton = document.getElementById('bounceButton');
  const rotateButton = document.getElementById('rotateButton');
  const pulseButton = document.getElementById('pulseButton');
  const shakeButton = document.getElementById('shakeButton');
  const fadeButton = document.getElementById('fadeButton');
  const zoomButton = document.getElementById('zoomButton');
  const slideInButton = document.getElementById('slideInButton');
  const slideOutButton = document.getElementById('slideOutButton');
  const flipButton = document.getElementById('flipButton');
  const spinButton = document.getElementById('spinButton');
  const sampleText = document.getElementById('sampleTextInput');

  changeTextColorButton.addEventListener('click', function() {
    const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
    sampleText.style.color = randomColor;
  });

  changeBgColorButton.addEventListener('click', function() {
    const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
    document.body.style.backgroundColor = randomColor;
  });

  changeTextSizeButton.addEventListener('click', function() {
    const randomSize = Math.floor(Math.random() * 40) + 10; // Random size between 10 and 50px
    sampleText.style.fontSize = randomSize + 'px';
  });

  changeTextStyleButton.addEventListener('click', function() {
    const styles = ['normal', 'italic', 'oblique'];
    const randomStyle = styles[Math.floor(Math.random() * styles.length)];
    sampleText.style.fontStyle = randomStyle;
  });

  resetButton.addEventListener('click', function() {
    sampleText.style.color = '';
    document.body.style.backgroundColor = '';
    sampleText.style.fontSize = '';
    sampleText.style.fontStyle = '';
    sampleText.classList.remove('slide-in-animation', 'slide-out-animation', 'flip-animation', 'spin-animation', 'bounce-animation', 'rotate-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'zoom-animation');
  });

  bounceButton.addEventListener('click', function() {
    sampleText.classList.remove('rotate-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'zoom-animation', 'slide-in-animation', 'slide-out-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('bounce-animation');
  });

  rotateButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'zoom-animation', 'slide-in-animation', 'slide-out-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('rotate-animation');
  });

  pulseButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'shake-animation', 'fade-animation', 'zoom-animation', 'slide-in-animation', 'slide-out-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('pulse-animation');
  });

  shakeButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'pulse-animation', 'fade-animation', 'zoom-animation', 'slide-in-animation', 'slide-out-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('shake-animation');
  });

  fadeButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'pulse-animation', 'shake-animation', 'zoom-animation', 'slide-in-animation', 'slide-out-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('fade-animation');
  });

  zoomButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'slide-in-animation', 'slide-out-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('zoom-animation');
  });

  slideInButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'zoom-animation', 'slide-out-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('slide-in-animation');
  });

  slideOutButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'zoom-animation', 'slide-in-animation', 'flip-animation', 'spin-animation');
    sampleText.classList.toggle('slide-out-animation');
  });

  flipButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'zoom-animation', 'slide-in-animation', 'slide-out-animation', 'spin-animation');
    sampleText.classList.toggle('flip-animation');
  });

  spinButton.addEventListener('click', function() {
    sampleText.classList.remove('bounce-animation', 'rotate-animation', 'pulse-animation', 'shake-animation', 'fade-animation', 'zoom-animation', 'slide-in-animation', 'slide-out-animation', 'flip-animation');
    sampleText.classList.toggle('spin-animation');
  });

  const sampleTextInput = document.getElementById('sampleTextInput');
  sampleTextInput.addEventListener('input', function() {
    sampleText.innerText = sampleTextInput.value;
  });
});
